package com.example.eduardoshinkawa.quiz;

/**
 * Created by eduardoshinkawo on 6/2/15.
 */
public class Propriedades {

    public static String username = "";
    public static String alias = "";


}
