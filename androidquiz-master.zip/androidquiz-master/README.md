# androidquiz
Simple Android quiz made with Firebase on backend

Hey, hello there.

Was exploring Android development with Firebase. So I build a simple quiz with both. 
